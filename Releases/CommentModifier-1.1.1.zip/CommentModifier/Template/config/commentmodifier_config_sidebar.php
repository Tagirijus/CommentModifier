<li <?= $this->app->checkMenuSelection('CommentModifierController', 'show') ?>>
    <a href="/commentmodifier/config"><?= t('CommentModifier configuration') ?></a>
</li>
