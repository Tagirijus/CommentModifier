<?php

return array(
    'Modify task comments by certain rules' => 'Modifiziere Task Kommentare aufgrund gewisser Regeln',
    'CommentModifier configuration' => 'CommentModifier Einstellungen',
    'The URL regex is the part to be recognized and replaced by a HTML5 player. The filename regex is the part to be recognized as the filename title for the additional link to be placed.' => 'URL Regex ist der Teil, der für das Erkennen und Ersetzen durch einen HTML5 Player genutzt wird. Das Filename Regex hingegen ist der Part, der für das Erkennen und Nutzen für die Platzierung des Links vom Dateinamen genutzt wird.',
    'To make media URLs from external domains available, it is needed to modify the Content-Security-Policy header. Enter values here seperated by a space.' => 'Um Medien-URLs von externen Domains verfügbar zu machen, muss man den Content-Security-Policy Header erweitern. Gib hier Werte mit Space getrennt ein.'
);
